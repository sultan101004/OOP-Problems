//#include <iostream>
//#include <vector>
//#include <SFML/Graphics.hpp>
//
//class Histogram {
//private:
//    std::vector<double> bin_bounds;
//    std::vector<unsigned int> counts;
//    std::vector<sf::Color> bin_colors;
//
//    void generate_colors() {
//        bin_colors.clear();
//        for (size_t i = 0; i < counts.size(); ++i) {
//            int r = (i * 50) % 256;
//            int g = (i * 100) % 256;
//            int b = (i * 150) % 256;
//            bin_colors.push_back(sf::Color(r, g, b));
//        }
//    }
//
//    size_t find_bin(double value) const {
//        for (size_t i = 1; i < bin_bounds.size(); ++i) {
//            if (value < bin_bounds[i]) {
//                return i - 1;
//            }
//        }
//        return bin_bounds.size() - 2;
//    }
//
//public:
//    explicit Histogram(const std::vector<double>& bounds) : bin_bounds(bounds) {
//        if (bin_bounds.size() < 2) {
//            std::cerr << "Error: At least two bin bounds required\n";
//            return;
//        }
//
//        for (size_t i = 1; i < bin_bounds.size(); ++i) {
//            if (bin_bounds[i] <= bin_bounds[i - 1]) {
//                std::cerr << "Error: Bin bounds must be strictly increasing\n";
//                return;
//            }
//        }
//
//        counts.resize(bin_bounds.size() - 1, 0);
//        generate_colors();
//    }
//
//    Histogram() = delete;
//
//    void clear() {
//        for (auto& count : counts) {
//            count = 0;
//        }
//    }
//
//    void update(double value) {
//        if (value < bin_bounds.front()) {
//            counts.front()++;
//        }
//        else if (value >= bin_bounds.back()) {
//            counts.back()++;
//        }
//        else {
//            counts[find_bin(value)]++;
//        }
//    }
//
//    void display(std::ostream& os) const {
//        os << "Histogram with " << counts.size() << " bins:\n";
//        for (size_t i = 0; i < counts.size(); ++i) {
//            os << "[" << bin_bounds[i] << ", " << bin_bounds[i + 1] << "): "
//                << counts[i] << " items\n";
//        }
//    }
//
//    void display_graphic() const {
//        const unsigned int width = 800;
//        const unsigned int height = 600;
//        const unsigned int margin = 50;
//        const unsigned int chart_width = width - 2 * margin;
//        const unsigned int chart_height = height - 2 * margin;
//
//        sf::RenderWindow window(sf::VideoMode(width, height), "Histogram");
//
//        unsigned int max_count = 1;
//        for (auto count : counts) {
//            if (count > max_count) max_count = count;
//        }
//
//        float bin_width = static_cast<float>(chart_width) / counts.size();
//        std::vector<sf::RectangleShape> bars;
//
//        for (size_t i = 0; i < counts.size(); ++i) {
//            float bar_height = static_cast<float>(counts[i]) / max_count * chart_height;
//
//            sf::RectangleShape bar(sf::Vector2f(bin_width - 2, bar_height));
//            bar.setPosition(margin + i * bin_width + 1, height - margin - bar_height);
//            bar.setFillColor(bin_colors[i]);
//
//            bars.push_back(bar);
//        }
//
//        while (window.isOpen()) {
//            sf::Event event;
//            while (window.pollEvent(event)) {
//                if (event.type == sf::Event::Closed) {
//                    window.close();
//                }
//            }
//
//            window.clear(sf::Color::White);
//
//            for (const auto& bar : bars) {
//                window.draw(bar);
//            }
//
//            sf::Vertex x_axis[] = {
//                sf::Vertex(sf::Vector2f(margin, height - margin), sf::Color::Black),
//                sf::Vertex(sf::Vector2f(width - margin, height - margin), sf::Color::Black)
//            };
//
//            sf::Vertex y_axis[] = {
//                sf::Vertex(sf::Vector2f(margin, height - margin), sf::Color::Black),
//                sf::Vertex(sf::Vector2f(margin, margin), sf::Color::Black)
//            };
//
//            window.draw(x_axis, 2, sf::Lines);
//            window.draw(y_axis, 2, sf::Lines);
//
//            window.display();
//        }
//    }
//};
//
//int main() {
//    // Create histogram with 5 bins
//    Histogram hist({ 0.0, 10.0, 20.0, 30.0, 40.0, 50.0 });
//
//    // Add sample data
//    hist.update(5.0);    // [0,10)
//    hist.update(15.0);   // [10,20)
//    hist.update(25.0);   // [20,30)
//    hist.update(35.0);   // [30,40)
//    hist.update(45.0);   // [40,50)
//    hist.update(-5.0);   // Clamped to [0,10)
//    hist.update(55.0);   // Clamped to [40,50)
//    hist.update(12.0);   // [10,20)
//    hist.update(18.0);   // [10,20)
//    hist.update(22.0);   // [20,30)
//
//    // Display in console
//    hist.display(std::cout);
//
//    // Display graphical version
//    hist.display_graphic();
//
//    return 0;
//}
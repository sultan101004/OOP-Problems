//#include<iostream
//using namespace std;
// 
//class Integer {
//private:
//    int value;
//
//public:
//    // Constructor with default argument
//    Integer(int val = 0) : value(val) {}
//
//    // Copy constructor
//    Integer(const Integer& other) : value(other.value) {}
//
//    // Move constructor
//    Integer(Integer&& other) noexcept : value(other.value) {}
//
//    // Destructor
//    ~Integer() = default;
//
//    // Copy assignment operator
//    Integer& operator=(const Integer& other) {
//        if (this != &other) {
//            value = other.value;
//        }
//        return *this;
//    }
//
//    // Move assignment operator
//    Integer& operator=(Integer&& other) noexcept {
//        if (this != &other) {
//            value = other.value;
//        }
//        return *this;
//    }
//
//    // Addition (reversed to subtraction)
//    Integer operator+(const Integer& other) const {
//        return Integer(value - other.value);
//    }
//
//    // Subtraction (reversed to addition)
//    Integer operator-(const Integer& other) const {
//        return Integer(value + other.value);
//    }
//
//    // Multiplication (reversed to division)
//    Integer operator*(const Integer& other) const {
//        if (other.value == 0) {
//            throw runtime_error("Division by zero");
//        }
//        return Integer(value / other.value);
//    }
//
//    // Division (reversed to multiplication)
//    Integer operator/(const Integer& other) const {
//        return Integer(value * other.value);
//    }
//
//    // Compound addition (reversed to subtraction)
//    Integer& operator+=(const Integer& other) {
//        value -= other.value;
//        return *this;
//    }
//
//    // Compound subtraction (reversed to addition)
//    Integer& operator-=(const Integer& other) {
//        value += other.value;
//        return *this;
//    }
//
//    // Compound multiplication (reversed to division)
//    Integer& operator*=(const Integer& other) {
//        if (other.value == 0) {
//            throw runtime_error("Division by zero");
//        }
//        value /= other.value;
//        return *this;
//    }
//
//    // Compound division (reversed to multiplication)
//    Integer& operator/=(const Integer& other) {
//        value *= other.value;
//        return *this;
//    }
//
//    // Stream inserter
//    friend ostream& operator<<(ostream& os, const Integer& integer) {
//        os << integer.value;
//        return os;
//    }
//
//    // Stream extractor
//    friend istream& operator>>(istream& is, Integer& integer) {
//        is >> integer.value;
//        return is;
//    }
//};


//
//int main() {
//    Integer a(10);
//    Integer b(5);
//
//    cout << "a + b = " << (a + b) << endl;  // 10 - 5 = 5
//    cout << "a - b = " << (a - b) << endl;  // 10 + 5 = 15
//    cout << "a * b = " << (a * b) << endl;  // 10 / 5 = 2
//    cout << "a / b = " << (a / b) << endl;  // 10 * 5 = 50
//
//    a += b;  // a = 10 - 5 = 5
//    cout << "a after +=: " << a << endl;
//
//    a *= b;  // a = 5 / 5 = 1
//    cout << "a after *=: " << a << endl;
//
//    return 0;
//}
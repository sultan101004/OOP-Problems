//#include <iostream>
//#include <string>
//#include <vector>
//#include <cstdlib>
//#include <ctime>
//#include <iomanip>
//using namespace std;
//
//// Page Class
//class Page {
//public:
//    int number;
//    string text;
//    Page(int num, string txt) : number(num), text(txt) {}
//
//    friend ostream& operator<<(ostream& os, const Page& p) {
//        os << setw(20) << left << "  Page Number:" << p.number << "\n"
//            << setw(20) << left << "  Text:" << p.text;
//        return os;
//    }
//    void setNumber(int num) { number = num; }
//    void setText(string txt) { text = txt; }
//    string getText() { return text; }
//    int getNumber() { return number; }
//    void print() { cout << *this; }
//};
//
//// Book Class
//class Book {
//public:
//    int isbn;
//    string author;
//    string title;
//    vector<Page*> pages;
//
//    Book(int isb, string title, string author, Page& p) : isbn(isb), author(author), title(title) {
//        pages.push_back(&p);
//    }
//    Book() : isbn(0), author(""), title("") {}
//
//    void setISBN(int num) { isbn = num; }
//    int getISBN() { return isbn; }
//    void setTitle(string t) { title = t; }
//    string getTitle() { return title; }
//    void setAuthor(string auth) { author = auth; }
//    string getAuthor() { return author; }
//
//    friend ostream& operator<<(ostream& os, const Book& b) {
//        os << setw(20) << left << "  ISBN:" << b.isbn << "\n"
//            << setw(20) << left << "  Author:" << b.author << "\n"
//            << setw(20) << left << "  Title:" << b.title << "\n"
//            << setw(20) << left << "  Pages:" << "";
//        for (size_t i = 0; i < b.pages.size(); ++i) {
//            os << "\n    Page " << (i + 1) << ":\n" << *b.pages[i];
//        }
//        return os;
//    }
//};
//
//// Account Class
//class Account {
//private:
//    int books_borrowed;
//    int books_lost;
//    int reserved_books;
//    float fine_amount;
//
//public:
//    Account() : books_borrowed(0), books_lost(0), reserved_books(0), fine_amount(0.0) {}
//    Account(int books_bw, int books_lt, int rd_books, float fine_am)
//        : books_borrowed(books_bw), books_lost(books_lt), reserved_books(rd_books), fine_amount(fine_am) {
//    }
//
//    void setBooksBorrowed(int num) { books_borrowed = num; }
//    int getBooksBorrowed() { return books_borrowed; }
//    void setBooksLost(int num) { books_lost = num; }
//    int getBooksLost() { return books_lost; }
//    void setReservedBooks(int num) { reserved_books = num; }
//    int getReservedBooks() { return reserved_books; }
//    void setFineAmount(float amount) { fine_amount = amount; }
//    float getFineAmount() { return fine_amount; }
//    void addFine(float amount) { fine_amount += amount; }
//    void payFine(float amount) {
//        if (amount <= fine_amount) {
//            fine_amount -= amount;
//        }
//        else {
//            cout << "Amount exceeds the fine amount.\n";
//        }
//    }
//    void borrowBook() { books_borrowed++; }
//    void returnBook() {
//        if (books_borrowed > 0) {
//            books_borrowed--;
//        }
//        else {
//            cout << "No books to return.\n";
//        }
//    }
//    void loseBook() { books_lost++; }
//    void recoverBook() {
//        if (books_lost > 0) {
//            books_lost--;
//        }
//        else {
//            cout << "No lost books to recover.\n";
//        }
//    }
//    void clearAccount() {
//        books_borrowed = 0;
//        books_lost = 0;
//        reserved_books = 0;
//        fine_amount = 0.0;
//    }
//
//    friend ostream& operator<<(ostream& os, const Account& a) {
//        os << setw(20) << left << "  Books Borrowed:" << a.books_borrowed << "\n"
//            << setw(20) << left << "  Books Lost:" << a.books_lost << "\n"
//            << setw(20) << left << "  Reserved Books:" << a.reserved_books << "\n"
//            << setw(20) << left << "  Fine Amount:" << fixed << setprecision(2) << a.fine_amount;
//        return os;
//    }
//};
//
//// User Class
//class User {
//public:
//    int id;
//    string name;
//    string email;
//    string password;
//    double fine = 0.0;
//    bool finePaid = false;
//    Account ac;
//    int days = 0;
//    bool loggedin = false;
//
//    User(int id, string name, string email, string password)
//        : id(id), name(name), email(email), password(password), ac() {
//        if (id == 0) {
//            cout << "Enter your id: ";
//            while (true) {
//                cin >> id;
//                if (cin.fail() || id < 0) {
//                    cout << "Invalid input. Please enter a valid id: ";
//                    cin.clear();
//                    cin.ignore(10000, '\n');
//                }
//                else {
//                    break;
//                }
//            }
//        }
//        if (name == "") {
//            cout << "Enter your name: \n";
//            getline(cin, name);
//            setName(name);
//        }
//        if (email == "") {
//            cout << "Enter your email: \n";
//            getline(cin, email);
//            setEmail(email);
//        }
//        if (password == "") {
//            cout << "Enter your password: \n";
//            getline(cin, password);
//            setPassword(password);
//        }
//    }
//    User(string name, string password) : id(0), name(name), email(""), password(password), ac() {}
//    User() : id(0), name(""), email(""), password("") {}
//
//    void setName(string n) { name = n; }
//    string getName() { return name; }
//    void setEmail(string e) { email = e; }
//    string getEmail() { return email; }
//    void setPassword(string p) { password = p; }
//    string getPassword() { return password; }
//    void setID(int id) { this->id = id; }
//    int getID() { return id; }
//    void clearAccount() {
//        cout << "Clearing Account\n";
//        ac.clearAccount();
//    }
//
//    friend ostream& operator<<(ostream& os, const User& u) {
//        os << setw(20) << left << "  User ID:" << u.id << "\n"
//            << setw(20) << left << "  Name:" << u.name << "\n"
//            << setw(20) << left << "  Email:" << u.email << "\n"
//            << setw(20) << left << "  Password:" << u.password << "\n"
//            << "  Account Details:\n" << u.ac;
//        return os;
//    }
//    void print() { cout << *this; }
//};
//
//// Student Class
//class Student : public User {
//    int rollno;
//    string dept;
//    string grade;
//    vector<Book> borrowedBooks;
//
//public:
//    Student(int id, string name, string email, string password, int rollno, string dept, string grade)
//        : User(id, name, email, password), rollno(rollno), dept(dept), grade(grade) {
//    }
//
//    void setRollno(int r) { rollno = r; }
//    int getRollno() { return rollno; }
//    void setDept(string d) { dept = d; }
//    string getDept() { return dept; }
//    void setGrade(string g) { grade = g; }
//    string getGrade() { return grade; }
//
//    bool borrowBook(vector<Book>& availableBooks, int index) {
//        if (borrowedBooks.size() == 0) {
//            if (index >= 0 && index < availableBooks.size()) {
//                borrowedBooks.push_back(availableBooks[index]);
//                cout << getName() << " borrowed: " << availableBooks[index].getTitle() << endl;
//                return true;
//            }
//            else {
//                cout << "Invalid book index." << endl;
//                return false;
//            }
//        }
//        else {
//            cout << "You have already borrowed a book. You cannot borrow another book.\n";
//            return false;
//        }
//    }
//
//    bool paymentScheme() {
//        int finePayed = 0;
//        do {
//            cout << "Returned after Days: " << days << "\n";
//            if (days / 7 <= 2) {
//                fine = 7 * 15;
//            }
//            else if (days / 14 <= 2) {
//                fine = 14 * 20;
//            }
//            else {
//                fine = 0;
//            }
//            cout << "Return Book\n";
//            cout << "Paying Book Fine: " << fine << "\n Input Fine: ";
//            cin >> finePayed;
//            if (finePayed >= fine) {
//                cout << "Left Rs: " << finePayed - fine << endl;
//                finePaid = true;
//            }
//            else {
//                cout << "Fine not paid. Please pay the fine.\n";
//            }
//        } while (finePayed < fine);
//        return true;
//    }
//
//    bool returnBook(int index) {
//        if (index >= 0 && index < borrowedBooks.size() && paymentScheme()) {
//            cout << getName() << " returned: " << borrowedBooks[index].getTitle() << endl;
//            borrowedBooks.erase(borrowedBooks.begin() + index);
//            return true;
//        }
//        else {
//            cout << "Invalid index for return." << endl;
//            return false;
//        }
//    }
//
//    void listBorrowedBooks() {
//        cout << getName() << "'s borrowed books:" << endl;
//        for (auto& book : borrowedBooks) {
//            cout << " - " << book.getTitle() << endl;
//        }
//    }
//
//    friend ostream& operator<<(ostream& os, Student& s) {
//        os << "Student\n"
//            << setw(20) << left << "  User ID:" << s.getID() << "\n"
//            << setw(20) << left << "  Name:" << s.getName() << "\n"
//            << setw(20) << left << "  Email:" << s.getEmail() << "\n"
//            << setw(20) << left << "  Roll No:" << s.rollno << "\n"
//            << setw(20) << left << "  Department:" << s.dept << "\n"
//            << setw(20) << left << "  Grade:" << s.grade << "\n"
//            << setw(20) << left << "  Borrowed Books:" << s.borrowedBooks.size();
//        return os;
//    }
//};
//
//// Faculty Class
//class Faculty : public User {
//    int emp_id;
//    string dept;
//    vector<Book> borrowedBooks;
//
//public:
//    Faculty(int id, string name, string email, string password, int emp_id, string dept)
//        : User(id, name, email, password), emp_id(emp_id), dept(dept) {
//    }
//
//    void setEmpID(int id) { emp_id = id; }
//    int getEmpID() { return emp_id; }
//    void setDept(string d) { dept = d; }
//    string getDept() { return dept; }
//
//    void borrowBook(vector<Book>& availableBooks, int index) {
//        if (index >= 0 && index < availableBooks.size()) {
//            borrowedBooks.push_back(availableBooks[index]);
//            cout << getName() << " borrowed: " << availableBooks[index].getTitle() << endl;
//        }
//        else {
//            cout << "Invalid book index." << endl;
//        }
//    }
//
//    bool paymentScheme() {
//        int finePayed = 0;
//        days = rand() % 30 + 1;
//        do {
//            cout << "Returned after Days: " << days << "\n";
//            if (days > 21) {
//                fine = days * 15;
//            }
//            else {
//                fine = 0;
//            }
//            cout << "Return Book\n";
//            cout << "Paying Book Fine: " << fine << "\n Input Fine: ";
//            cin >> finePayed;
//            if (finePayed >= fine) {
//                cout << "Left Rs: " << finePayed - fine << endl;
//                finePaid = true;
//            }
//            else {
//                cout << "Fine not paid. Please pay the fine.\n";
//            }
//        } while (finePayed < fine);
//        return true;
//    }
//
//    bool returnBook(int index) {
//        if (index >= 0 && index < borrowedBooks.size() && paymentScheme()) {
//            cout << getName() << " returned: " << borrowedBooks[index].getTitle() << endl;
//            borrowedBooks.erase(borrowedBooks.begin() + index);
//            return true;
//        }
//        else {
//            cout << "Invalid index for return." << endl;
//            return false;
//        }
//    }
//
//    void listBorrowedBooks() {
//        cout << getName() << "'s borrowed books:" << endl;
//        for (auto& book : borrowedBooks) {
//            cout << " - " << book.getTitle() << endl;
//        }
//    }
//
//    friend ostream& operator<<(ostream& os, Faculty& f) {
//        os << "Faculty\n"
//            << setw(20) << left << "  User ID:" << f.getID() << "\n"
//            << setw(20) << left << "  Name:" << f.getName() << "\n"
//            << setw(20) << left << "  Email:" << f.getEmail() << "\n"
//            << setw(20) << left << "  Employee ID:" << f.emp_id << "\n"
//            << setw(20) << left << "  Department:" << f.dept << "\n"
//            << setw(20) << left << "  Borrowed Books:" << f.borrowedBooks.size();
//        return os;
//    }
//
//    void print() {
//        cout << *this;
//    }
//};
//
//// Librarian Class
//class Librarian : public User, public Account {
//    int emp_id;
//    string dept;
//    vector<Book> books;
//    Account a;
//
//public:
//    Librarian(int id, string name, string email, string password, int emp_id, string dep, vector<Book> book)
//        : User(id, name, email, password), emp_id(emp_id), dept(dep), books(book) {
//    }
//
//    void setEmpID(int id) { emp_id = id; }
//    int getEmpID() { return emp_id; }
//    void setDept(string d) { dept = d; }
//    string getDept() { return dept; }
//
//    void addBook(Book* b) { books.push_back(*b); }
//    void removeBook(int index) {
//        if (index >= 0 && index < books.size()) {
//            books.erase(books.begin() + index);
//        }
//        else {
//            cout << "Invalid index for removal." << endl;
//        }
//    }
//    void listBooks() {
//        cout << "Books in the library:\n";
//        for (size_t i = 0; i < books.size(); ++i) {
//            cout << "----------------------------------------\n"
//                << "Book " << (i + 1) << "\n" << books[i] << "\n";
//        }
//        cout << "----------------------------------------\n";
//    }
//    void viewBook(int index) {
//        if (index >= 0 && index < books.size()) {
//            cout << "Book Details:\n----------------------------------------\n" << books[index]
//                << "\n----------------------------------------\n";
//        }
//        else {
//            cout << "Invalid index for viewing." << endl;
//        }
//    }
//
//    friend ostream& operator<<(ostream& os, Librarian& l) {
//        os << "Librarian\n"
//            << setw(20) << left << "  User ID:" << l.getID() << "\n"
//            << setw(20) << left << "  Name:" << l.getName() << "\n"
//            << setw(20) << left << "  Email:" << l.getEmail() << "\n"
//            << setw(20) << left << "  Password:" << l.getPassword() << "\n"
//            << setw(20) << left << "  Employee ID:" << l.emp_id << "\n"
//            << setw(20) << left << "  Department:" << l.dept << "\n"
//            << setw(20) << left << "  Number of Books:" << l.books.size() << "\n";
//        return os;
//    }
//};
//
//// Person Class
//class Person {
//    string name;
//    string password;
//
//public:
//    Person(string name, string password) : name(name), password(password) {}
//    Person() : name(" "), password(" ") {}
//
//    void setName(string name) { this->name = name; }
//    string getName() { return name; }
//    void setPassword(string password) { this->password = password; }
//    string getPassword() { return password; }
//
//    friend ostream& operator<<(ostream& os, const Person& p) {
//        os << setw(20) << left << "  Name:" << p.name << "\n"
//            << setw(20) << left << "  Password:" << p.password;
//        return os;
//    }
//};
//
//// LMS Class
//class LMS : public Person {
//    vector<User> user;
//    Librarian* l;
//
//public:
//    LMS(string name, string password) : Person(name, password) { l = nullptr; }
//
//    bool verifyLogin(vector<User> user, User& u) {
//        for (size_t i = 0; i < user.size(); ++i) {
//            if (user[i].getName() == u.getName() && user[i].getPassword() == u.getPassword()) {
//                cout << "Login successful.\nWelcome " << u.getName() << "\n";
//                u.loggedin = true;
//                return true;
//            }
//        }
//        return false;
//    }
//
//    bool Login(string name, string password) {
//        for (size_t i = 0; i < user.size(); ++i) {
//            if (user[i].getName() == name && user[i].getPassword() == password) {
//                cout << "Login successful.\nWelcome " << name << "\n";
//                user[i].loggedin = true;
//                return true;
//            }
//        }
//        return false;
//    }
//
//    void addPerson(User& u) {
//        if (!verifyLogin(user, u)) {
//            user.push_back(u);
//            cout << "User added successfully.\n";
//        }
//        else {
//            cout << "User already exists.\n";
//        }
//    }
//
//    void removePerson(int index, User& u) {
//        if (u.loggedin) {
//            if (index >= 0 && index < user.size()) {
//                user.erase(user.begin() + index);
//            }
//            else {
//                cout << "Invalid index for removal." << endl;
//            }
//        }
//        else {
//            cout << "You are not logged in.\n";
//            verifyLogin(user, u);
//        }
//    }
//
//    void listPersons() {
//        cout << "Persons in the library:\n";
//        for (size_t i = 0; i < user.size(); ++i) {
//            cout << "----------------------------------------\n"
//                << "Person " << (i + 1) << "\n" << user[i] << "\n";
//        }
//        cout << "----------------------------------------\n";
//    }
//
//    friend ostream& operator<<(ostream& os, LMS& l) {
//        os << "Library Management System\n";
//        os << setw(20) << left << "  Name:" << l.getName() << "\n"
//            << setw(20) << left << "  Password:" << l.getPassword() << "\n"
//            << setw(20) << left << "  Users:" << l.user.size() << "\n";
//        for (size_t i = 0; i < l.user.size(); ++i) {
//            os << "    User " << (i + 1) << ":\n"
//                << setw(20) << left << "      Name:" << l.user[i].getName() << "\n"
//                << setw(20) << left << "      Email:" << l.user[i].getEmail() << "\n"
//                << setw(20) << left << "      ID:" << l.user[i].getID() << "\n";
//        }
//        return os;
//    }
//
//    bool registerUser(string name, string email, string password) {
//        for (size_t i = 0; i < user.size(); ++i) {
//            if (user[i].getName() == name) {
//                cout << "User already exists.\n";
//                return false;
//            }
//        }
//        User newUser(rand() % 1000, name, email, password);
//        addPerson(newUser);
//        cout << "User registered successfully.\n";
//        return true;
//    }
//};
//
//// Library Class
//class Library {
//    string libName;
//    LMS lms;
//    vector<Librarian> librarian;
//
//public:
//    Library(string libName, LMS lms) : libName(libName), lms(lms) {}
//    void setLibName(string name) { libName = name; }
//    string getLibName() { return libName; }
//    void addLibrarian(Librarian& l) { librarian.push_back(l); }
//    void removeLibrarian(int index) {
//        if (index >= 0 && index < librarian.size()) {
//            librarian.erase(librarian.begin() + index);
//        }
//        else {
//            cout << "Invalid index for removal." << endl;
//        }
//    }
//    void listLibrarians() {
//        cout << "====================================\nLibrarians in the Library\n====================================\n";
//        for (size_t i = 0; i < librarian.size(); ++i) {
//            cout << "Librarian " << (i + 1) << "\n----------------------------------------\n"
//                << librarian[i] << "\n----------------------------------------\n";
//        }
//    }
//    void listBooks() {
//        cout << "====================================\nBooks in the Library\n====================================\n";
//        for (size_t i = 0; i < librarian.size(); ++i) {
//            librarian[i].listBooks();
//        }
//    }
//    void viewBook() {
//        cout << "====================================\nViewing Book\n====================================\n";
//        for (size_t i = 0; i < librarian.size(); ++i) {
//            librarian[i].viewBook(0);
//        }
//    }
//};
//
//int main() {
//    srand(time(0));
//
//    Page p1(1, "This is the first page.");
//    Book b1(123, "Book 1", "Author 1", p1);
//    Book b2(1234, "Book 2", "Author 2", p1);
//    Book b3(12345, "Book 3", "Author 3", p1);
//    Book b4(123456, "Book 4", "Author 4", p1);
//    Book b5(1234567, "Book 5", "Author 5", p1);
//    Book b6(345678, "Book 6", "Author 6", p1);
//    Book b7(456789, "Book 7", "Author 7", p1);
//    Book b8(4567890, "Book 8", "Author 8", p1);
//    Book b9(145901, "Book 9", "Author 9", p1);
//    Book b10(123412, "Book 10", "Author 10", p1);
//
//    vector<Book> availBooks = { b1, b2, b3, b4, b5, b6, b7, b8, b9, b10 };
//    Account a1(1, 2, 3, 4);
//    User u1(1, "Name", "Email", "Password");
//    Student s1(1, "Jonny", "Jonny@gmail.com", "Pass1122", 1, "Computer Science", "A");
//    Faculty f1(1, "Name", "Email", "Password", 1, "Computer Science");
//    Librarian l1(1, "Name", "Email", "Password", 1, "Computer Science", availBooks);
//    LMS lms("LMS", "Password");
//    Library library("My Library", lms);
//    library.addLibrarian(l1);
//    library.listLibrarians();
//    library.listBooks();
//    library.viewBook();
//
//    return 0;
//}